#include <iostream>
int main() {
    using namespace std;
    cout << "hello world\n";
}

